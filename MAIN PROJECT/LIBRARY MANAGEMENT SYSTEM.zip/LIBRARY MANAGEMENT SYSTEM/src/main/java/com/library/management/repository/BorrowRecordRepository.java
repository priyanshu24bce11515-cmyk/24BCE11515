package com.library.management.repository;

import com.library.management.model.BorrowRecord;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/** @author Priyanshu_Singh@PK24 */
@Repository
public interface BorrowRecordRepository extends MongoRepository<BorrowRecord, String> {
    List<BorrowRecord> findByStudentId(String studentId);
}
