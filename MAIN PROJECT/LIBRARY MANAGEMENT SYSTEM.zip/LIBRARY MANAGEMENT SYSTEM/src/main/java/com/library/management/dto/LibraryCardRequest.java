package com.library.management.dto;

import java.time.LocalDate;

public class LibraryCardRequest {

    private String cardNumber;
    private String studentId;
    private LocalDate issueDate;
    private String status;

    public LibraryCardRequest() {
    }

    public LibraryCardRequest(String cardNumber, String studentId, LocalDate issueDate, String status) {
        this.cardNumber = cardNumber;
        this.studentId = studentId;
        this.issueDate = issueDate;
        this.status = status;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public LocalDate getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(LocalDate issueDate) {
        this.issueDate = issueDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
