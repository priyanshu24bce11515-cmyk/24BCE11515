package com.library.management.controller;

import com.library.management.dto.LibraryCardRequest;
import com.library.management.model.LibraryCard;
import com.library.management.service.LibraryCardService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/library-cards")
public class LibraryCardController {

    private final LibraryCardService libraryCardService;

    public LibraryCardController(LibraryCardService libraryCardService) {
        this.libraryCardService = libraryCardService;
    }

    @PostMapping
    public ResponseEntity<LibraryCard> createLibraryCard(@RequestBody LibraryCardRequest request) {
        LibraryCard createdCard = libraryCardService.createLibraryCard(request);
        return new ResponseEntity<>(createdCard, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<LibraryCard>> getAllLibraryCards() {
        return ResponseEntity.ok(libraryCardService.getAllLibraryCards());
    }

    @GetMapping("/{id}")
    public ResponseEntity<LibraryCard> getLibraryCardById(@PathVariable String id) {
        return ResponseEntity.ok(libraryCardService.getLibraryCardById(id));
    }

    @PutMapping("/{cardNumber}/status")
    public ResponseEntity<LibraryCard> updateLibraryCardStatus(@PathVariable String cardNumber, @RequestBody java.util.Map<String, String> body) {
        String status = body.get("status");
        LibraryCard updatedCard = libraryCardService.updateLibraryCardStatus(cardNumber, status);
        return ResponseEntity.ok(updatedCard);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLibraryCard(@PathVariable String id) {
        libraryCardService.deleteLibraryCard(id);
        return ResponseEntity.noContent().build();
    }
}
