package com.library.management.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

/*
 * Model: Staff
 * Author: Priyanshu_Singh@PK24
 */
@Document(collection = "staff")
public class Staff {

    @Id
    private String id;
    private String name;
    private String designation;
    private String email;

    @DBRef
    private Department department;

    public Staff() {
    }

    public Staff(String name, String designation, String email, Department department) {
        this.name = name;
        this.designation = designation;
        this.email = email;
        this.department = department;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDesignation() { return designation; }
    public void setDesignation(String designation) { this.designation = designation; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public Department getDepartment() { return department; }
    public void setDepartment(Department department) { this.department = department; }
}
