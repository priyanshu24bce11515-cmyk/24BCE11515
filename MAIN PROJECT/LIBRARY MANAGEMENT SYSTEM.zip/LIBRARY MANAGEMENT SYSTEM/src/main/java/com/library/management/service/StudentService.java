package com.library.management.service;

import com.library.management.model.Student;
import com.library.management.repository.StudentRepository;
import com.library.management.exception.ResourceNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {

    private final StudentRepository studentRepository;

    public StudentService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    public Student createStudent(Student student) {
        return studentRepository.save(student);
    }

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public Student getStudentById(String id) {
        java.util.Optional<Student> opt = studentRepository.findById(id);
        if (opt.isPresent()) {
            return opt.get();
        }
        throw new ResourceNotFoundException("Student not found");
    }

    public Student updateStudent(String id, Student updatedInfo) {
        Student student = getStudentById(id);
        student.setName(updatedInfo.getName());
        student.setRollNo(updatedInfo.getRollNo());
        student.setEmail(updatedInfo.getEmail());
        student.setDepartment(updatedInfo.getDepartment());
        return studentRepository.save(student);
    }

    public void deleteStudent(String id) {
        studentRepository.deleteById(id);
    }
}
