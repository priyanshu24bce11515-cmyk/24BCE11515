package com.library.management.repository;

import com.library.management.model.Book;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

/** @author Priyanshu_Singh@PK24 */
@Repository
public interface BookRepository extends MongoRepository<Book, String> {
    java.util.List<Book> findByAuthorContainingIgnoreCase(String author);
}
