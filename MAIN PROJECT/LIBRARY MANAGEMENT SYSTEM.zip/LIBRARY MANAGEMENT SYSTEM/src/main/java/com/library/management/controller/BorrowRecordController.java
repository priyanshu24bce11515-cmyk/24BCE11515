package com.library.management.controller;

import com.library.management.dto.IssueBookRequest;
import com.library.management.model.BorrowRecord;
import com.library.management.service.BorrowRecordService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/borrow-records")
public class BorrowRecordController {

    private final BorrowRecordService borrowRecordService;

    public BorrowRecordController(BorrowRecordService borrowRecordService) {
        this.borrowRecordService = borrowRecordService;
    }

    @PostMapping("/borrow")
    public ResponseEntity<BorrowRecord> issueBook(@RequestBody IssueBookRequest request) {
        BorrowRecord record = borrowRecordService.issueBook(request);
        return new ResponseEntity<>(record, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<BorrowRecord>> getAllBorrowRecords() {
        return ResponseEntity.ok(borrowRecordService.getAllBorrowRecords());
    }

    @GetMapping("/{id}")
    public ResponseEntity<BorrowRecord> getBorrowRecordById(@PathVariable String id) {
        return ResponseEntity.ok(borrowRecordService.getBorrowRecordById(id));
    }

    @PutMapping("/{id}/return")
    public ResponseEntity<BorrowRecord> returnBook(@PathVariable String id) {
        BorrowRecord record = borrowRecordService.returnBook(id);
        return ResponseEntity.ok(record);
    }

    @PutMapping("/{id}/renew")
    public ResponseEntity<BorrowRecord> renewBook(@PathVariable String id, @RequestBody java.util.Map<String, String> requestData) {
        String dateStr = requestData.get("newDueDate");
        java.time.LocalDate newDueDate = java.time.LocalDate.parse(dateStr);
        BorrowRecord record = borrowRecordService.renewBook(id, newDueDate);
        return ResponseEntity.ok(record);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<BorrowRecord> updateBorrowRecord(@PathVariable String id, @RequestBody java.util.Map<String, Object> requestBody) {
        BorrowRecord record = borrowRecordService.updateBorrowRecord(id, requestBody);
        return ResponseEntity.ok(record);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBorrowRecord(@PathVariable String id) {
        borrowRecordService.deleteBorrowRecord(id);
        return ResponseEntity.noContent().build();
    }
}
