package com.library.management.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

/*
 * Model: Student
 * Author: Priyanshu_Singh@PK24
 */
@Document(collection = "students")
public class Student {

    @Id
    private String id;
    private String name;
    private String rollNo;
    private String email;

    @DBRef
    private Department department;

    public Student() {
    }

    public Student(String name, String rollNo, String email, Department department) {
        this.name = name;
        this.rollNo = rollNo;
        this.email = email;
        this.department = department;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getRollNo() { return rollNo; }
    public void setRollNo(String rollNo) { this.rollNo = rollNo; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public Department getDepartment() { return department; }
    public void setDepartment(Department department) { this.department = department; }
}
