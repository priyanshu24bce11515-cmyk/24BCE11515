package com.library.management.dto;

import com.library.management.model.Book;

public class IssueBookRequest {
    private String studentId;
    private String bookId;
    private String issuedBy;
    private String dueDate;

    public IssueBookRequest() {
    }

    public IssueBookRequest(String studentId, String bookId, String issuedBy, String dueDate) {
        this.studentId = studentId;
        this.bookId = bookId;
        this.issuedBy = issuedBy;
        this.dueDate = dueDate;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getIssuedBy() {
        return issuedBy;
    }

    public void setIssuedBy(String issuedBy) {
        this.issuedBy = issuedBy;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }
}
