package com.library.management.service;

import com.library.management.dto.IssueBookRequest;
import com.library.management.model.Book;
import com.library.management.model.BorrowRecord;
import com.library.management.model.Student;
import com.library.management.repository.BookRepository;
import com.library.management.repository.BorrowRecordRepository;
import com.library.management.repository.StudentRepository;
import com.library.management.exception.ResourceNotFoundException;
import com.library.management.exception.ResourceUnavailableException;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class BorrowRecordService {

    private final BorrowRecordRepository borrowRecordRepository;
    private final BookRepository bookRepository;
    private final StudentRepository studentRepository;

    public BorrowRecordService(BorrowRecordRepository borrowRecordRepository, BookRepository bookRepository, StudentRepository studentRepository) {
        this.borrowRecordRepository = borrowRecordRepository;
        this.bookRepository = bookRepository;
        this.studentRepository = studentRepository;
    }

    public BorrowRecord issueBook(IssueBookRequest request) {
        // get student and book from db
        String studentId = request.getStudentId();
        String bookId = request.getBookId();

        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found"));
        
        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found"));

        if (book.getAvailableCopies() <= 0) {
            throw new ResourceUnavailableException("Book is currently unavailable");
        }

        // decrease available copies
        book.setAvailableCopies(book.getAvailableCopies() - 1);
        bookRepository.save(book);

        BorrowRecord record = new BorrowRecord();
        record.setStudent(student);
        record.setBook(book);
        record.setIssueDate(LocalDate.now());
        // default loan period is 14 days
        record.setDueDate(LocalDate.now().plusDays(14));
        record.setStatus("BORROWED");

        return borrowRecordRepository.save(record);
    }

    public List<BorrowRecord> getAllBorrowRecords() {
        return borrowRecordRepository.findAll();
    }

    public BorrowRecord getBorrowRecordById(String id) {
        return borrowRecordRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("BorrowRecord not found"));
    }

    public BorrowRecord returnBook(String recordId) {
        BorrowRecord record = getBorrowRecordById(recordId);

        if ("RETURNED".equalsIgnoreCase(record.getStatus())) {
            throw new ResourceUnavailableException("Book is already returned");
        }

        record.setStatus("RETURNED");

        Book book = record.getBook();
        if (book == null) {
            throw new ResourceNotFoundException("Associated Book not found for this record");
        }

        book.setAvailableCopies(book.getAvailableCopies() + 1);
        bookRepository.save(book);

        return borrowRecordRepository.save(record);
    }

    public BorrowRecord renewBook(String recordId, LocalDate newDueDate) {
        BorrowRecord record = getBorrowRecordById(recordId);

        if ("RETURNED".equalsIgnoreCase(record.getStatus())) {
            throw new ResourceUnavailableException("Cannot renew a book that is already returned");
        }

        record.setDueDate(newDueDate);
        record.setStatus("RENEWED");

        return borrowRecordRepository.save(record);
    }

    public BorrowRecord updateBorrowRecord(String id, java.util.Map<String, Object> reqBody) {
        BorrowRecord record = getBorrowRecordById(id);

        // TODO: add extra validation later
        if (reqBody.get("status") != null) {
            String status = (String) reqBody.get("status");
            if ("RETURNED".equalsIgnoreCase(status) && !"RETURNED".equalsIgnoreCase(record.getStatus())) {
                return returnBook(id);
            }
            record.setStatus(status);
        }

        if (reqBody.get("dueDate") != null) {
            record.setDueDate(LocalDate.parse((String) reqBody.get("dueDate")));
        }

        return borrowRecordRepository.save(record);
    }

    public void deleteBorrowRecord(String id) {
        BorrowRecord record = getBorrowRecordById(id);
        borrowRecordRepository.delete(record);
    }
}
