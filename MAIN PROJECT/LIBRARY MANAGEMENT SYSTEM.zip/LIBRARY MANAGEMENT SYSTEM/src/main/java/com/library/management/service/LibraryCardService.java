package com.library.management.service;

import com.library.management.dto.LibraryCardRequest;
import com.library.management.exception.ResourceNotFoundException;
import com.library.management.model.LibraryCard;
import com.library.management.model.Student;
import com.library.management.repository.LibraryCardRepository;
import com.library.management.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LibraryCardService {

    private final LibraryCardRepository libraryCardRepository;
    private final StudentRepository studentRepository;

    public LibraryCardService(LibraryCardRepository libraryCardRepository, StudentRepository studentRepository) {
        this.libraryCardRepository = libraryCardRepository;
        this.studentRepository = studentRepository;
    }

    public LibraryCard createLibraryCard(LibraryCardRequest request) {
        java.util.Optional<Student> studentOpt = studentRepository.findById(request.getStudentId());
        if (!studentOpt.isPresent()) {
            throw new ResourceNotFoundException("Student not found!");
        }
        Student student = studentOpt.get();

        LibraryCard libraryCard = new LibraryCard(
                request.getCardNumber(),
                student,
                request.getIssueDate(),
                request.getStatus()
        );

        return libraryCardRepository.save(libraryCard);
    }

    public List<LibraryCard> getAllLibraryCards() {
        return libraryCardRepository.findAll();
    }

    public LibraryCard getLibraryCardById(String id) {
        return libraryCardRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Card not found"));
    }

    public LibraryCard updateLibraryCardStatus(String cardNumber, String newStatus) {
        LibraryCard libraryCard = libraryCardRepository.findByCardNumber(cardNumber)
                .orElseThrow(() -> new ResourceNotFoundException("Card not found"));
        
        libraryCard.setStatus(newStatus);
        return libraryCardRepository.save(libraryCard);
    }

    public void deleteLibraryCard(String id) {
        libraryCardRepository.deleteById(id);
    }
}
