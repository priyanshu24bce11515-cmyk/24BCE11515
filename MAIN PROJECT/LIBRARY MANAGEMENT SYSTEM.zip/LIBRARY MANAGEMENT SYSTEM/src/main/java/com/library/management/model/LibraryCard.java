package com.library.management.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;

/*
 * Model: LibraryCard
 * Author: Priyanshu_Singh@PK24
 * 
 * TODO: check if we need to store expiry date separately
 */
@Document(collection = "library_cards")
public class LibraryCard {

    @Id
    private String id;
    
    private String cardNumber;

    @DBRef
    private Student student;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate issueDate;

    private String status;

    public LibraryCard() {
    }

    public LibraryCard(String cardNumber, Student student, LocalDate issueDate, String status) {
        this.cardNumber = cardNumber;
        this.student = student;
        this.issueDate = issueDate;
        this.status = status;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getCardNumber() { return cardNumber; }
    public void setCardNumber(String cardNumber) { this.cardNumber = cardNumber; }

    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }

    public LocalDate getIssueDate() { return issueDate; }
    public void setIssueDate(LocalDate issueDate) { this.issueDate = issueDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
