package com.library.management.repository;

import com.library.management.model.Student;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

/** @author Priyanshu_Singh@PK24 */
@Repository
public interface StudentRepository extends MongoRepository<Student, String> {
}
